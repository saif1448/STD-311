package org.example.models;

public record MeetingSchedule(String dateTime, BusinessContact businessContact, String topic) {

}
